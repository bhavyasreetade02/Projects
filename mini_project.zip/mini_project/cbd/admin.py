from django.contrib import admin
from .models import Create_user

admin.site.register(Create_user)
