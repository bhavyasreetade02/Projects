from django.shortcuts import render
from .models import Create_user
from django.contrib import messages

def index(request):
    return render(request, 'index.html')

def register(request):
    if request.method=='POST':
        user=Create_user()
        user.user_name=request.POST.get('username_register', False)
        user.user_email=request.POST.get('email_register', False)
        user.user_password=request.POST.get('password_register', False)

        if Create_user.objects.filter(user_name=user.user_name).exists():
            messages.info(request,"Username already taken.Please Signup again")
            return render(request, 'index.html')

        elif Create_user.objects.filter(user_email=user.user_email).exists():
            messages.info(request,"Account already exists. Please Login")
            return render(request, 'index.html')
        else:
            user.save()
            messages.info(request, "Your account has been created successfully")
            return render(request, 'index.html')
    else:
        return render(request, 'index.html')

def login_user(request):
    if request.method=='POST':
        user_login = Create_user()
        user_login.user_email = request.POST.get('email_login', False)
        user_login.user_password = request.POST.get('password_login', False)

        if Create_user.objects.filter(user_email=user_login.user_email,user_password=user_login.user_password).exists():
            return render(request,'main.html')
        else:
            messages.info(request,'Invalid Credentials')
            return render(request,'index.html')
    else:
        return render(request,"index.html")

def predict(request):
    word=str(request.GET['input_text'])
    lt=["Bastard","Idiot","Stupid","Rascal","gayyyy","poor","rude","fuck","bitch","shit","black","dark","skinny","ugly","ugliness","greedy","ass","dick","evil"]
    predic="Not bullying"
    for i in lt:
        print(word.find(i))
        if word.find(i)!=-1:
            predic="Bullying"
    return render(request, "main.html", {'pred': predic})
