from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name='cbd-index'),
    path('register/',views.register,name="cbd-register"),
    path('main/',views.login_user,name="cbd-main"),
    path('predict/',views.predict,name="prediction-ml"),
]