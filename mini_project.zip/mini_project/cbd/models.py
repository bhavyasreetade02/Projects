from django.db import models

class Create_user(models.Model):
    user_name = models.CharField(max_length=30, default="")
    user_email = models.EmailField(max_length=50, default="")
    user_password = models.CharField(max_length=15, default="")

    def __str__(self):
        return self.user_name
