import socket
from tkinter import *
client = Tk()
client.title("Client")
client.geometry("1000x300")
input_text = Label(client, text="Enter text:\n(Maximum 30 characters) ",font=('segeo ui emoji',15,'bold'))
input_text.place(x=40,y=50)
inp=Text(client,width=50,height=1,font=('segeo ui emoji',15,'bold'))
inp.place(x=300,y=50)

def connection():
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as s:
        s.connect(('localhost', 12385))
        msg=inp.get(1.0,'end-1c')
        s.send(bytes(msg,'utf-8'))
        cipher=s.recv(1024).decode()
        output = Label(client,text=cipher,bg="yellow",font=('segeo ui emoji',15,'bold'))
        output.place(x=160, y=200)

recv_text=Label(client,text="Cipher text:  ",font=('segeo ui emoji',15,'bold'))
recv_text.place(x=40,y=200)
button=Button(client,text="Submit",command=connection,font=('segeo ui emoji',14,'bold'))
button.place(x=400,y=120)
client.mainloop()
