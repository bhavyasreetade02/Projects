import binascii
import socket
import random
from tkinter import *

server=Tk()
server.title("Server")
server.geometry("1500x500")

def random_key(p):
    key1 = ""
    for i in range(int(p)):
        temp = random.randint(0, 1)
        temp = str(temp)
        key1 += temp
    return key1


def xor(p, q, m):
    temp = ""
    for i in range(m):
        if int(p[i]) == int(q[i]):
            temp += "0"
        else:
            temp += "1"
    return temp


def BinaryToDecimal(binary):
    string = int(binary, 2)
    return string

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind(('localhost', 12385))
    print("Waiting for connections....")
    s.listen()
    conn, address = s.accept()
    lbl1=Label(server,text=f"Connected to {address}",font=('segeo ui emoji',13,'bold'))
    lbl1.place(x=10,y=10)

with conn:
    while True:
        text=conn.recv(1024).decode()
        msg = text
        text_ascii = [ord(x) for x in text]
        text_bin = [format(y, '08b') for y in text_ascii]
        text_bin = "".join(text_bin)
        n1=int(len(text_bin)//2)

        lbl2 = Label(server, text="Modified Feistel Cipher",font=('segeo ui emoji',15,'bold'))
        lbl2.place(x=600, y=50)
        lbl3 = Label(server, text="Plain Text:",font=('segeo ui emoji',13,'bold'))
        lbl3.place(x=10, y=100)
        lbl4 = Label(server, text=msg,font=('segeo ui emoji',13,'bold'))
        lbl4.place(x=110, y=100)
        msg_ascii = [ord(x) for x in msg]
        msg_bin = [format(y, '08b') for y in msg_ascii]
        msg_bin = "".join(msg_bin)
        n2 = int(len(msg_bin) // 2)

        L1=text_bin[0:n1]
        R1=text_bin[n1::]
        m1=len(R1)
        K1=random_key(m1)
        K2=random_key(m1)

        f1=xor(R1,K1,m1)
        R2=xor(f1,L1,m1)
        L2=R1

        f2=xor(R2,K2,m1)
        R3=xor(f2,L2,m1)
        L3=R2

        bin_data=L3+R3
        str_data=""
        for i in range(0, len(bin_data), 7):
            temp_data1 = bin_data[i:i + 7]
            decimal_data1 = BinaryToDecimal(temp_data1)
            str_data = str_data + chr(decimal_data1)
        label=Label(server,text="Normal Cipher text:",font=('segeo ui emoji',13,'bold'))
        label.place(x=10,y=150)
        text_label=Label(server,text=str_data,bg="yellow",font=('segeo ui emoji',13,'bold'))
        text_label.place(x=180,y=150)

        Left1 = [msg_bin[0:n2]]
        Right1 = [msg_bin[n2:]]
        m2 = len(Right1[0])

        Key1 = [random_key(m2)]
        fun1 = []
        length = len(msg)
        if length > 100:
            length = 100
        print("\n\tENCRYPTION PROCESS:\n")
        for i in range(0, length):
            fun1.append(xor(Right1[i], Key1[i],m2))
            Right1.append(xor(fun1[i], Left1[i],m2))
            print("Right half ",i,":",Right1[i+1])
            Left1.append(xor(Right1[i], Key1[i],m2))
            print("Left half ", i, ":", Left1[i + 1])
            Key1.append(random_key(m2))
        binary_data = Left1[i] + Right1[i]
        string_data = ''
        k = i
        for j in range(0, len(binary_data), 7):
            temp_data2 = binary_data[j:j + 7]
            decimal_data2 = BinaryToDecimal(temp_data2)
            string_data =string_data + chr(decimal_data2)

        lbl5 = Label(server, text="Modified Cipher Text:",font=('segeo ui emoji',13,'bold'))
        lbl5.place(x=10, y=230)
        lbl6 = Label(server, text=string_data,bg="yellow",font=('segeo ui emoji',13,'bold'))
        lbl6.place(x=200, y=230)
        conn.send(bytes(string_data,'utf-8'))

        Left2 = []
        Right2 = []
        Left2.append(Right1[k])
        Right2.append(Left1[k])
        fun2 = []
        RS = []
        print("\n\tDECRYPTION PROCESS:\n")
        for i in range(0, length):
            RS.append(xor(Right2[i], Key1[k - i - 1],m2))
            fun2.append(xor(RS[i], Key1[k - i - 1],m2))
            Right2.append(xor(Left2[i], fun2[i],m2))
            print("Right half",k-i,":",Right2[i])
            Left2.append(RS[i])
            print("Left half:",k-i,":",Left2[i])

        PT = Right2[length - 1] + Left2[length - 1]
        PT = int(PT, 2)
        plain_text=str(PT)
        dec_label1 = Label(server, text="Decimal Representation of Retrieved Plain Text:", font=('segeo ui emoji', 13, 'bold'))
        dec_label1.place(x=10,y=300)
        dec_label2= Text(server,height=3,font=('segeo ui emoji', 13, 'bold'))
        dec_label2.insert(END,plain_text)
        dec_label2.place(x=410, y=300)
        try:
            if len(plain_text)%2!=0:
                pass
        except :
            RPT = str(binascii.unhexlify('0%x' % PT))

            text_label=Label(server,text="Retrieved Plain Text:",font=('segeo ui emoji',13,'bold'))
            text_label.place(x=10,y=380)
            res_label=Label(server,text=RPT[2:len(RPT)-1],bg='yellow',font=('segeo ui emoji',13,'bold'))
            res_label.place(x=210,y=380)


        RPT = str(binascii.unhexlify('%x' % PT))

        text_label = Label(server, text="Retrieved Plain Text:",font=('segeo ui emoji',13,'bold'))
        text_label.place(x=10, y=380)
        res_label = Label(server, text=RPT[2:len(RPT)-1],bg='yellow',font=('segeo ui emoji' ,13,'bold'))
        res_label.place(x=210, y=380)
        print("Decimal Representation of Retrieved Plain Text:", PT)
        break

server.mainloop()