from tkinter import *
parent=Tk()
parent.title("Welcome")
parent.geometry("400x300")
name=Label(parent,text="Name: ",font=('segeo ui emoji',15,'bold'))
name.place(x=50,y=50)
e1=Entry(parent,font=('segeo ui emoji',15,'bold'))
e1.place(x=150,y=50)
regno=Label(parent,text="Reg No: ",font=('segeo ui emoji',15,'bold'))
regno.place(x=50,y=100)
e2=Entry(parent,font=('segeo ui emoji',15,'bold'))
e2.place(x=150,y=100)

def show():
    if e1.get()=="Bhavya Sree" and e2.get()=="124003334":
         res=Label(parent,text="Verified",font=('segeo ui emoji',15,'bold'))
         res.place(x=150,y=200)
    else:
        res = Label(parent, text="Invalid",font=('segeo ui emoji',15,'bold'))
        res.place(x=150, y=200)

btn=Button(parent,text="Submit",command=show,font=('segeo ui emoji',15,'bold'))
btn.place(x=150,y=150)
parent.mainloop()
