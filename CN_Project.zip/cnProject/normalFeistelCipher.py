import binascii
import random

def random_key(p):
    key1 = ""
    for i in range(int(p)):
        temp = random.randint(0, 1)
        temp = str(temp)
        key1 += temp
    return key1

def xor(p, q):
    temp = ""
    for i in range(n):
        if (p[i] == q[i]):
            temp += "0"
        else:
            temp += "1"
    return temp

def BinaryToDecimal(binary):
    string = int(binary, 2)
    return string

print("\n\t\t\tNORMAL FEISTEL STRUCTURE")
PT = input("\nEnter plain text:")
print("Plain Text is:", PT)

PT_Ascii = [ord(x) for x in PT]
PT_Bin = [format(y, '08b') for y in PT_Ascii]
PT_Bin = "".join(PT_Bin)

n = int(len(PT_Bin) // 2)
L1 = PT_Bin[0:n]
R1 = PT_Bin[n::]
m = len(R1)

K1 = random_key(m)
K2 = random_key(m)

fun1 = xor(R1, K1)
R2 = xor(fun1, L1)
L2 = R1

fun2 = xor(R2, K2)
Right3 = xor(fun2, L2)
Left3 = R2

bin_data = Left3 + Right3
str_data = ' '

for i in range(0, len(bin_data), 7):
    temp_data = bin_data[i:i + 7]
    decimal_data = BinaryToDecimal(temp_data)
    str_data = str_data + chr(decimal_data)

print("Cipher Text:", str_data)

Left4 = Left3
Right4 = Right3

fun3 = xor(Left4, K2)
Left5 = xor(Right4, fun3)
Right5 = Left4

fun4 = xor(Left5, K1)
Left6 = xor(Right5, fun4)
Right6 = Left5
PT = Left6 + Right6

PT = int(PT, 2)
print("decimal:",PT)
RPT = str(binascii.unhexlify('%x' % PT))
print("Retrieved Plain Text is: ", RPT[2:len(RPT) - 1])
